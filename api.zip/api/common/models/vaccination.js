'use strict';

module.exports = function(Vaccination) {

};
