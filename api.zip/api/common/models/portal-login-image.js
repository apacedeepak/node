'use strict';

module.exports = function(Portalloginimage) {

};
