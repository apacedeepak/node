'use strict';

module.exports = function(Mailconfiguration) {

};
