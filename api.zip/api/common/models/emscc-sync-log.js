'use strict';

module.exports = function(Emsccsynclog) {

};
