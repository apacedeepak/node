'use strict';

module.exports = function(Allergies) { 

};
