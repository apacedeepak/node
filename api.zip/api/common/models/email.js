'use strict';

module.exports = function(Email) {

};
