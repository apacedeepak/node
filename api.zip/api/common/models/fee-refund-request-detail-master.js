'use strict';

module.exports = function(Feerefundrequestdetailmaster) {


    


};
