'use strict';

module.exports = function(Studenthomework) {

};
