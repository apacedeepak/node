'use strict';

module.exports = function(Hygiene) {

};
