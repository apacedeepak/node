'use strict';

module.exports = function(Productmaster) {

};
