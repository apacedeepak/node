'use strict';

module.exports = function(Countryconfiguration) {

};
