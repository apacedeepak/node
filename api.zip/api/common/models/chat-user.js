'use strict';

module.exports = function(Chatuser) {

};
