'use strict';

module.exports = function(Batchplanningtimetable) {

};
