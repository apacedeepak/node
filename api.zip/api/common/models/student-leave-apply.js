'use strict';

module.exports = function(Studentleaveapply) {

};
