'use strict';

module.exports = function(Submittedhomework) {

};
