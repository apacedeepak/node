'use strict';

module.exports = function(Usercalendar) {

};
