import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomeworkAssigntoPage } from './homework-assignto';

@NgModule({
  declarations: [
    HomeworkAssigntoPage,
  ],
  imports: [
    IonicPageModule.forChild(HomeworkAssigntoPage),
  ],
})
export class HomeworkAssigntoPageModule {}
