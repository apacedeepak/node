import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DuedetailspopupPage } from './duedetailspopup';

@NgModule({
  declarations: [
    DuedetailspopupPage,
  ],
  imports: [
    IonicPageModule.forChild(DuedetailspopupPage),
  ],
})
export class DuedetailspopupPageModule {}
