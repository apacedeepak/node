import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomeworkRemarkPage } from './homework-remark';

@NgModule({
  declarations: [
    HomeworkRemarkPage,
  ],
  imports: [
    IonicPageModule.forChild(HomeworkRemarkPage),
  ],
})
export class HomeworkRemarkPageModule {}
