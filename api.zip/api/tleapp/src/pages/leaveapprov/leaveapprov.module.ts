import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LeaveapprovPage } from './leaveapprov';

@NgModule({
  declarations: [
    LeaveapprovPage,
  ],
  imports: [
    IonicPageModule.forChild(LeaveapprovPage),
  ],
})
export class LeaveapprovPageModule {}
